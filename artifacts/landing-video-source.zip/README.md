# Landing page recording: sources

How `public/landing/tour.mp4` and the `public/landing/*.webp` screenshots were made (2026-11-25).

1. `capture/`: Playwright scripts that drive the real app against a local Supabase
   stack (never the hosted project). `seed.mjs` creates sample people and the room,
   `notes|pdfcap|wb|live|pack.mjs` record one scene each as numbered JPEG frames
   plus a JSON file of cursor positions, `stills*.mjs` take the card screenshots.
   They expect the app on http://localhost:3100 and `../sb.env` from `supabase status -o env`.
2. `remotion/`: the Remotion project. Copy each scene's frames to `public/f/<scene>/`
   and its JSON to `src/`, then `npx remotion render ProductTour out/tour.mp4 --scale=0.75`.
   Camera moves and scene speeds are in `src/config.ts`.
3. Final encode: `ffmpeg -i out/tour.mp4 -an -c:v libx264 -preset veryslow -crf 27 -pix_fmt yuv420p -movflags +faststart tour.mp4`.

If scene lengths change, update `TOUR_CHAPTERS` in `src/components/home/landing-demos.tsx`.
