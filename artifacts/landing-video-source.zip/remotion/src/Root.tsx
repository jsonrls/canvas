import "./index.css";
import { Composition } from "remotion";
import { ProductTour } from "./Composition";
import { FPS, TOTAL } from "./config";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="ProductTour"
    component={ProductTour}
    durationInFrames={TOTAL}
    fps={FPS}
    width={1920}
    height={1200}
  />
);
