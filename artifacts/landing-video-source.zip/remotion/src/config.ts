import notes from "./notes.json";
import pdf from "./pdf.json";
import whiteboard from "./whiteboard.json";
import live from "./live.json";
import pack from "./pack.json";

export const FPS = 60;
export const W = 1440; // capture size in CSS px; every coordinate below uses it
export const H = 900;
/** Recorded states are shown at 20 per second before `speed` is applied. */
const CAPTURE_RATE = 20;
export const FADE = 14;

export interface Shot {
  i: string;
  x: number;
  y: number;
  d: number;
}
/** Camera keyframe: at capture frame `at`, centre on (x, y) at scale `s`. */
export type Key = [at: number, x: number, y: number, s: number];

interface SceneInput {
  id: string;
  label: string;
  frames: Shot[];
  speed: number;
  camera: Key[];
}

const INPUTS: SceneInput[] = [
  {
    id: "notes",
    label: "Notes",
    frames: notes.frames,
    speed: 1.15,
    camera: [
      [0, 720, 450, 1.12],
      [10, 720, 450, 1.12],
      [34, 850, 372, 1.72],
      [128, 850, 380, 1.78],
      [156, 850, 380, 1.6],
    ],
  },
  {
    id: "pdf",
    label: "PDF",
    frames: pdf.frames,
    speed: 1.5,
    camera: [
      [0, 745, 420, 1.28],
      [34, 745, 420, 1.28],
      [58, 745, 580, 1.7],
      [134, 745, 590, 1.74],
      [152, 960, 440, 1.5],
      [227, 975, 430, 1.56],
    ],
  },
  {
    id: "whiteboard",
    label: "Board",
    frames: whiteboard.frames,
    speed: 1.5,
    camera: [
      [0, 700, 452, 1.2],
      [30, 700, 452, 1.2],
      [62, 930, 372, 1.42],
      [150, 940, 372, 1.42],
      [176, 990, 470, 1.5],
      [205, 990, 480, 1.56],
      [251, 820, 460, 1.24],
    ],
  },
  {
    id: "live",
    label: "Live",
    frames: live.frames,
    speed: 1.6,
    camera: [
      [0, 560, 340, 1.3],
      [66, 560, 340, 1.3],
      [92, 930, 400, 1.45],
      [182, 930, 400, 1.5],
      [200, 920, 390, 1.45],
      [260, 930, 400, 1.52],
    ],
  },
  {
    id: "pack",
    label: "Pack",
    frames: pack.frames,
    speed: 1.7,
    camera: [
      [0, 600, 420, 1.3],
      [66, 600, 430, 1.3],
      [104, 575, 400, 1.55],
      [168, 575, 400, 1.6],
      [190, 575, 450, 1.6],
      [250, 575, 410, 1.58],
      [298, 575, 420, 1.66],
    ],
  },
];

export const SCENES = INPUTS.map((scene) => ({
  ...scene,
  /** Capture frames advanced per video frame. */
  step: (CAPTURE_RATE * scene.speed) / FPS,
  duration: Math.round(
    (scene.frames.length / (CAPTURE_RATE * scene.speed)) * FPS,
  ),
}));

let start = 0;
export const TIMELINE = SCENES.map((scene) => {
  const from = start;
  start += scene.duration;
  return { ...scene, from };
});
export const TOTAL = start;
