import {
  AbsoluteFill,
  Easing,
  Img,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { FADE, H, type Key, type Shot, TIMELINE, TOTAL, W } from "./config";

const EASE = Easing.bezier(0.45, 0, 0.2, 1);

/** Eased camera between keyframes, clamped so the window always fills the frame. */
function cameraAt(keys: Key[], at: number, drift: number) {
  let index = keys.findIndex(([time]) => time > at);
  if (index === -1) index = keys.length - 1;
  const from = keys[Math.max(0, index - 1)];
  const to = keys[index];
  const t =
    to[0] === from[0]
      ? 1
      : EASE(Math.min(1, Math.max(0, (at - from[0]) / (to[0] - from[0]))));
  const mix = (a: number, b: number) => a + (b - a) * t;
  // Nothing fully stops: a slow breath on the scale while the camera holds.
  const s = mix(from[3], to[3]) * (1 + 0.006 * Math.sin(drift / 70));
  const halfW = W / 2 / s;
  const halfH = H / 2 / s;
  const x = Math.min(W - halfW, Math.max(halfW, mix(from[1], to[1])));
  const y = Math.min(H - halfH, Math.max(halfH, mix(from[2], to[2])));
  return { s, x, y };
}

function Cursor({ x, y, press }: { x: number; y: number; press: number }) {
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        transform: `scale(${1 - 0.14 * press})`,
        transformOrigin: "0 0",
      }}
    >
      <div
        style={{
          position: "absolute",
          left: -17,
          top: -17,
          width: 34,
          height: 34,
          borderRadius: 17,
          background: "rgba(37, 99, 235, 0.22)",
          opacity: press,
          transform: `scale(${0.6 + 0.4 * press})`,
        }}
      />
      <svg width="22" height="22" viewBox="0 0 24 24" style={{ position: "absolute", left: -3, top: -2, filter: "drop-shadow(0 2px 3px rgba(15, 27, 61, 0.35))" }}>
        <path
          d="M4 2.5v17.2l4.7-4.4 3 6.7 2.9-1.3-3-6.6h6.5L4 2.5z"
          fill="#0F1B3D"
          stroke="#fff"
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
}

function Scene({
  id,
  frames,
  step,
  camera,
}: {
  id: string;
  frames: Shot[];
  step: number;
  camera: Key[];
}) {
  const frame = useCurrentFrame();
  const { width } = useVideoConfig();
  const at = Math.min(frames.length - 1, frame * step);
  const index = Math.floor(at);
  const shot = frames[index];
  const next = frames[Math.min(frames.length - 1, index + 1)];
  const part = at - index;
  const cursorX = shot.x + (next.x - shot.x) * part;
  const cursorY = shot.y + (next.y - shot.y) * part;
  // The press eases out over the frames after a recorded click.
  let press = 0;
  for (let back = 0; back < 5; back++) {
    if (frames[Math.max(0, index - back)].d) {
      press = Math.max(press, 1 - (back + part) / 5);
    }
  }
  const { s, x, y } = cameraAt(camera, at, frame);
  const fit = width / W;

  return (
    <AbsoluteFill style={{ backgroundColor: "#fff", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          width: W,
          height: H,
          transformOrigin: "0 0",
          transform: `scale(${fit * s}) translate(${W / 2 / s - x}px, ${H / 2 / s - y}px)`,
        }}
      >
        <Img
          src={staticFile(`f/${id}/${shot.i}`)}
          style={{ position: "absolute", width: W, height: H }}
        />
        <Cursor x={cursorX} y={cursorY} press={press} />
      </div>
    </AbsoluteFill>
  );
}

/** Each scene fades in over the tail of the one before; the last fades to the first so the loop has no cut. */
export const ProductTour: React.FC = () => {
  const frame = useCurrentFrame();
  const first = TIMELINE[0];

  return (
    <AbsoluteFill style={{ backgroundColor: "#fff" }}>
      {TIMELINE.map((scene, index) => (
        <Sequence
          key={scene.id}
          from={scene.from}
          durationInFrames={scene.duration + FADE}
          name={scene.label}
        >
          <AbsoluteFill
            style={{
              opacity:
                index === 0
                  ? 1
                  : interpolate(frame - scene.from, [0, FADE], [0, 1], {
                      extrapolateLeft: "clamp",
                      extrapolateRight: "clamp",
                    }),
            }}
          >
            <Scene {...scene} />
          </AbsoluteFill>
        </Sequence>
      ))}
      <Sequence from={TOTAL - FADE} durationInFrames={FADE} name="Loop seam">
        <AbsoluteFill
          style={{
            opacity: interpolate(frame - (TOTAL - FADE), [0, FADE], [0, 1]),
          }}
        >
          <Scene {...first} frames={[first.frames[0]]} />
        </AbsoluteFill>
      </Sequence>
    </AbsoluteFill>
  );
};
