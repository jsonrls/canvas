import { chromium } from "playwright";
import { createClient } from "@supabase/supabase-js";
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { randomBytes } from "node:crypto";
export const BASE = "http://localhost:3100";
const env = Object.fromEntries(readFileSync("../sb.env","utf8").trim().split("\n").map(l=>{const i=l.indexOf("=");return [l.slice(0,i),l.slice(i+1).replace(/^"|"$/g,"")]}));
if (!env.API_URL.startsWith("http://127.0.0.1")) throw new Error("not local");
export const admin = createClient(env.API_URL, env.SERVICE_ROLE_KEY, {auth:{persistSession:false}});
export const PEOPLE = {ana:"Ana Reyes", marco:"Marco Diaz", lea:"Lea Tan", noah:"Noah Cruz", ivy:"Ivy Santos", theo:"Theo Lim", mia:"Mia Flores", sam:"Sam Ong", zoe:"Zoe Garcia", ben:"Ben Torres", kai:"Kai Ramos", eli:"Eli Navarro", joy:"Joy Castro", max:"Max Rivera", nia:"Nia Mendoza", leo:"Leo Aquino", ada:"Ada Bautista", gus:"Gus Perez"};
export async function seedUsers(){
  const out = existsSync("users.json") ? JSON.parse(readFileSync("users.json")) : {};
  for (const [k,name] of Object.entries(PEOPLE)) if(!out[k]){
    const email=`${k}@example.com`, password=randomBytes(12).toString("hex");
    const {data,error}=await admin.auth.admin.createUser({email,password,email_confirm:true,user_metadata:{display_name:name}});
    if(error) throw error; out[k]={id:data.user.id,email,password,name};
  }
  writeFileSync("users.json",JSON.stringify(out)); return out;
}
export async function open(){ return chromium.launch({channel:"chromium",headless:true}); }
export async function login(browser,u,opts={}){
  const ctx=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:2,colorScheme:"light",...opts});
  const slot={ana:0,marco:3,lea:1}[u.email.split("@")[0]];
  // Yjs client ids stay random; only the palette slot (id % 5) is pinned so a person keeps one colour.
  if(slot!==undefined) await ctx.addInitScript(i=>{const g=crypto.getRandomValues.bind(crypto);crypto.getRandomValues=a=>{g(a);if(a instanceof Uint32Array&&a.length===1)a[0]=Math.floor(a[0]/10)*5+i;return a;};},slot);
  await ctx.addInitScript(()=>document.addEventListener("focusin",e=>e.target.setAttribute?.("spellcheck","false"),true));
  const page=await ctx.newPage();
  await page.goto(BASE+"/login"); 
  await page.fill('input[type=email]',u.email); await page.fill('input[type=password]',u.password);
  await page.keyboard.press("Enter"); await page.waitForURL(/\/rooms/);
  return page;
}
