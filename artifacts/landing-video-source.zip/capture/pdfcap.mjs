import {seedUsers,open,login,BASE} from "./lib.mjs"; import {Rec} from "./rec.mjs";
const u=await seedUsers(), b=await open(), R=BASE+"/rooms/history-study-group-14e34054a1?tool=pdf";
const [a,m,l]=await Promise.all([login(b,u.ana),login(b,u.marco,{deviceScaleFactor:1}),login(b,u.lea,{deviceScaleFactor:1})]);
for(const p of [a,m,l]){await p.goto(R);await p.waitForSelector(".pdf-annotation-layer");} await a.waitForTimeout(3500); await a.getByRole("button",{name:/collapse/i}).first().click(); await a.waitForTimeout(900);
const btn=(p,n)=>p.locator(".pdf-toolbar").getByRole("button",{name:n,exact:true}).first();
for(const p of [a]) for(let i=0;i<3;i++){ if(await btn(p,"Zoom in").isEnabled()){await btn(p,"Zoom in").click();await p.waitForTimeout(500);} }
for(let i=0;i<8;i++){ const c=a.locator(".pdf-toolbar [title*='Clear all']").first(); if(await c.isEnabled().catch(()=>false)){await c.click();await a.getByRole("button",{name:/^Clear \d+ mark/}).click();await a.waitForTimeout(600);} break; }
while(await a.locator(".pdf-mark--sticky").count()){await a.locator(".pdf-mark--sticky").first().click();await a.waitForTimeout(500);await a.getByRole("button",{name:"Delete annotation"}).click();await a.waitForTimeout(700);}
{const c=a.getByRole("button",{name:"Close comments and notes"});if(await c.isVisible())await c.click();}
await a.waitForTimeout(1500);
const box=async p=>p.locator(".pdf-annotation-layer").boundingBox();
const at=async(p,fx,fy)=>{const q=await box(p);return [q.x+q.width*fx,q.y+q.height*fy];};
console.log("layer",await box(a));
const drag=async(p,t,x1,y1,x2,y2)=>{await btn(p,t).click();const [ax,ay]=await at(p,x1,y1),[bx,by]=await at(p,x2,y2);await p.mouse.move(ax,ay);await p.mouse.down();await p.mouse.move((ax+bx)/2,by,{steps:4});await p.mouse.move(bx,by,{steps:4});await p.mouse.up();};
const H=.011;
const r=new Rec(a,"pdf",1000,600); await r.shot(16);
await r.to(btn(a,"Highlight"),16); await r.click(200,3); r.mark("highlight");
{const [x,y]=await at(a,.132,.501-H); await r.move(x,y,14); const [x2,y2]=await at(a,.868,.501+H); await r.drag(x2,y2,20);} await r.hold(6);
r.mark("marco"); await drag(m,"Highlight",.385,.322-H,.812,.322+H); for(let i=0;i<5;i++){await a.waitForTimeout(120);await r.shot(2);}
await drag(l,"Underline",.133,.4620,.832,.4620); 
await btn(l,"Sticky note").click(); {const [x,y]=await at(l,.915,.40);await l.mouse.click(x,y);} await l.waitForTimeout(400);
await l.locator(".pdf-comment-editor textarea").fill("Which towns? Let’s map these for Thursday."); await l.getByRole("button",{name:"Save note"}).click();
for(let i=0;i<8;i++){await a.waitForTimeout(140);await r.shot(2);} r.mark("sticky");
await r.to(a.locator(".pdf-mark--sticky").first(),18); await r.click(900,14); r.mark("open");
const rep=a.locator(".pdf-reply-form input"); if(await rep.isVisible()){ await r.to(rep,14); await r.click(150,2); for(const c of "Good idea. I’ll start with Mainz."){await a.keyboard.type(c);await a.waitForTimeout(15);await r.shot(1);} await r.to(a.locator(".pdf-reply-form button"),10); await r.click(400,24);} r.mark("end");
r.save(); await a.screenshot({path:"x-pdf2.png",scale:"css"}); await b.close();
