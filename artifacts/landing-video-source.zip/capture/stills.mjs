import {seedUsers,open,login,BASE} from "./lib.mjs";
const u=await seedUsers(), b=await open(), R=BASE+"/rooms/history-study-group-14e34054a1";
const a=await login(b,u.ana); const col=async()=>{await a.waitForTimeout(2500);const c=a.getByRole("button",{name:/collapse/i}).first();if(await c.isVisible().catch(()=>false)){await c.click();await a.waitForTimeout(900);}};
const park=()=>a.mouse.move(1430,450);
// PDF
await a.goto(R+"?tool=pdf"); await a.waitForSelector(".pdf-annotation-layer"); await col();
for(let i=0;i<3;i++){const z=a.locator(".pdf-toolbar").getByRole("button",{name:"Zoom in",exact:true}).first();if(await z.isEnabled()){await z.click();await a.waitForTimeout(500);}}
await a.locator(".pdf-toolbar").getByRole("button",{name:"Scroll PDF"}).first().click().catch(()=>{}); await park(); await a.waitForTimeout(1200);
await a.screenshot({path:"stills/pdf.png",clip:{x:283,y:488,width:632,height:300}});
await a.screenshot({path:"stills/pdf-full.png"});
// whiteboard
await a.goto(R+"?tool=whiteboard"); await a.waitForSelector("svg[aria-label='Collaborative whiteboard canvas']"); await col(); await a.getByRole("button",{name:"Reset view"}).first().click(); await park(); await a.waitForTimeout(1200);
await a.screenshot({path:"stills/board.png",clip:{x:96,y:196,width:660,height:560}});
await a.screenshot({path:"stills/ask.png",clip:{x:724,y:130,width:560,height:660}});
await a.screenshot({path:"stills/board-full.png"});
// study pack: generate once, save, reuse on a phone-sized window
await a.goto(R+"?tool=assistant"); await col(); await a.getByRole("button",{name:"Generate study pack"}).first().click(); await a.getByRole("dialog").getByRole("button",{name:"Generate study pack"}).click();
await a.waitForSelector("[aria-label='AI study pack views']",{timeout:150000}); await a.getByRole("button",{name:"Save guide"}).click(); await a.waitForFunction(()=>new URLSearchParams(location.search).get("guide"),null,{timeout:20000});
const guide=new URL(a.url()).searchParams.get("guide"); console.log("guide saved",!!guide); await park(); await a.waitForTimeout(800); await a.screenshot({path:"stills/pack-full.png"});
const ph=await login(b,u.ana,{viewport:{width:430,height:1400},deviceScaleFactor:3});
await ph.goto(`${R}?tool=assistant&guide=${guide}`); await ph.waitForSelector("[aria-label='AI study pack views']"); await ph.waitForTimeout(1500);
const panel=ph.locator("[role=tabpanel]").first(); console.log("panel",await panel.boundingBox()); await panel.screenshot({path:"stills/summary.png"});
await ph.goto(`${R}?tool=assistant&guide=${guide}&view=quiz`); await ph.waitForSelector("[aria-label='Answers for question 1']"); await ph.waitForTimeout(1200);
const opts=ph.locator("[aria-label='Answers for question 1'] button"); const n=await opts.count(); let hit=false;
for(let i=0;i<n&&!hit;i++){ if(i){await ph.getByRole("button",{name:"Reset quiz"}).click();await ph.waitForTimeout(300);} await opts.nth(i).click(); await ph.waitForTimeout(500); hit=(await ph.locator("[role=tabpanel]").first().innerText()).includes("Correct."); }
console.log("correct shown",hit); await ph.mouse.move(5,1390); await ph.waitForTimeout(400);
const q=ph.locator("[aria-label='Answers for question 1']").locator("xpath=ancestor::*[self::article or self::li or self::section or self::div][1]"); await ph.locator("[role=tabpanel]").first().screenshot({path:"stills/quiz-panel.png"});
// notes on a phone-sized window, with two other people in the document
const [m,l]=await Promise.all([login(b,u.marco,{deviceScaleFactor:1}),login(b,u.lea,{deviceScaleFactor:1})]);
for(const p of [m,l]){await p.goto(R);await p.waitForSelector("[contenteditable=true]");}
await ph.goto(R); await ph.waitForSelector("[contenteditable=true]"); await ph.waitForTimeout(2000);
const endOf=async(p,t)=>{await p.locator(".ProseMirror li").filter({hasText:t}).first().click();await p.keyboard.press("End");};
await endOf(m,"Books got cheaper"); await endOf(l,"Korea printed"); await ph.waitForTimeout(1500);
console.log("pm",await ph.locator(".ProseMirror").boundingBox()); await ph.screenshot({path:"stills/notes-phone.png"});
await b.close();
