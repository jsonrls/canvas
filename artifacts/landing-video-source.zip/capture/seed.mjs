import {createClient} from "@supabase/supabase-js";
import {seedUsers,open,login,BASE,admin} from "./lib.mjs";
const u=await seedUsers(); const b=await open();
const p=await login(b,u.ana);
let {data:room}=await admin.from("rooms").select("*").eq("name","History study group").maybeSingle();
{ const {data:d}=room?await admin.from("documents").select("id").eq("room_id",room.id):{data:[]};
 if(room && !d.length){ const e=await admin.from("rooms").delete().eq("id",room.id); if(e.error) throw e.error; room=null; } }
if(!room){
  const c=createClient(process.env.U,process.env.K,{auth:{persistSession:false}});
  const si=await c.auth.signInWithPassword({email:u.ana.email,password:u.ana.password}); if(si.error) throw si.error;
  const r=await c.rpc("create_study_room",{input_is_public:false,input_name:"History study group"}); if(r.error) throw r.error;
  room=(await admin.from("rooms").select("*").eq("name","History study group").single()).data;
}
for (const k of Object.keys(u)) { const {error}=await admin.from("room_members").upsert({room_id:room.id,user_id:u[k].id,role:k==="ana"?"owner":["marco","lea"].includes(k)?"editor":"viewer"}); if(error) console.log(k,error.message); }
const {data:docs}=await admin.from("documents").select("kind,title").eq("room_id",room.id); console.log(docs);
await p.goto(BASE+"/rooms"); await p.waitForTimeout(2500); await p.screenshot({path:"x-rooms.png",scale:"css"});
for (const t of ["notes","pdf","whiteboard","live","assistant"]){ await p.goto(`${BASE}/rooms/${room.slug}?tool=${t}`); await p.waitForTimeout(3500); await p.screenshot({path:`x-${t}.png`,scale:"css"}); }
await b.close();
