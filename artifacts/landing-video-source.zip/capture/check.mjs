import {chromium} from "playwright"; const b=await chromium.launch({channel:"chromium"}); const U="http://localhost:3000/";
const errs=[];
async function run(name,opts,fn){const c=await b.newContext(opts);const p=await c.newPage();p.on("console",m=>{if(m.type()==="error")errs.push(name+": "+m.text().slice(0,200))});p.on("pageerror",e=>errs.push(name+": "+e.message.slice(0,200)));await p.goto(U,{waitUntil:"networkidle"});await fn(p);await c.close();}
const state=p=>p.$eval("video",v=>({paused:v.paused,t:+v.currentTime.toFixed(2),ready:v.readyState,w:v.clientWidth,h:v.clientHeight,dur:+v.duration.toFixed(2)}));
await run("desktop",{viewport:{width:1440,height:900},deviceScaleFactor:1},async p=>{
  await p.locator("video").scrollIntoViewIfNeeded(); await p.waitForTimeout(3000); console.log("desktop autoplay",await state(p), await p.$$eval("[aria-label='Recording chapters'] button",es=>es.map(e=>(e.getAttribute("aria-label")||e.textContent)+":"+e.getAttribute("aria-pressed"))));
  await p.evaluate(()=>window.scrollTo(0,document.querySelector("video").getBoundingClientRect().top+scrollY-330)); await p.waitForTimeout(400);
  await p.getByRole("button",{name:"Board",exact:true}).click(); await p.waitForTimeout(4200); console.log("after Board",await state(p)); await p.screenshot({path:"v-hero.png"});
  await p.getByRole("button",{name:"Pause the recording"}).click(); await p.waitForTimeout(600); const s1=await state(p); await p.waitForTimeout(800); console.log("paused",s1,(await state(p)).t===s1.t);
  await p.evaluate(()=>scrollTo(0,0)); await p.waitForTimeout(300); await p.locator("video").scrollIntoViewIfNeeded(); await p.waitForTimeout(800); console.log("stays paused after scroll",(await state(p)).paused);
  for(const id of ["why","workspace"]){await p.locator("#"+id).scrollIntoViewIfNeeded();await p.waitForTimeout(900);await p.evaluate(i=>document.getElementById(i).scrollIntoView(),id);await p.waitForTimeout(900);await p.screenshot({path:`v-${id}.png`});}
  await p.evaluate(()=>scrollBy(0,820)); await p.waitForTimeout(900); await p.screenshot({path:"v-workspace2.png"});
  await p.locator("#packs-title").scrollIntoViewIfNeeded(); await p.evaluate(()=>document.getElementById("packs-title").scrollIntoView()); await p.waitForTimeout(900); await p.screenshot({path:"v-packs.png"});
  console.log("imgs",await p.$$eval("img[src*='landing']",es=>es.map(e=>e.currentSrc.split("url=")[1]?.split("&")[0]+":"+e.naturalWidth+"x"+e.clientWidth+"x"+e.clientHeight)));
});
await run("mobile",{viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true},async p=>{
  await p.locator("video").scrollIntoViewIfNeeded(); await p.waitForTimeout(2500); console.log("mobile",await state(p),"overflowX",await p.evaluate(()=>document.documentElement.scrollWidth-innerWidth));
  await p.evaluate(()=>window.scrollTo(0,document.querySelector("video").getBoundingClientRect().top+scrollY-120)); await p.waitForTimeout(500); await p.screenshot({path:"v-mobile.png"});
});
await run("reduced",{viewport:{width:1440,height:900},reducedMotion:"reduce"},async p=>{
  await p.locator("video").scrollIntoViewIfNeeded(); await p.waitForTimeout(2000); const s=await state(p); await p.getByRole("button",{name:"Play the recording"}).click(); await p.waitForTimeout(1200); console.log("reduced motion: before",s,"after play",await state(p));
});
console.log("errors",errs); await b.close();
