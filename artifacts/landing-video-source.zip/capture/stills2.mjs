import {seedUsers,open,login,BASE} from "./lib.mjs";
const u=await seedUsers(), b=await open(), R=BASE+"/rooms/history-study-group-14e34054a1";
const a=await login(b,u.ana); const col=async()=>{await a.waitForTimeout(2500);const c=a.getByRole("button",{name:/collapse/i}).first();if(await c.isVisible().catch(()=>false)){await c.click();await a.waitForTimeout(900);}};
await a.goto(R+"?tool=pdf"); await a.waitForSelector(".pdf-annotation-layer"); await col();
for(let i=0;i<3;i++){const z=a.locator(".pdf-toolbar").getByRole("button",{name:"Zoom in",exact:true}).first();if(await z.isEnabled()){await z.click();await a.waitForTimeout(500);}}
await a.mouse.move(1430,450); await a.waitForTimeout(1200); const L=await a.locator(".pdf-annotation-layer").boundingBox();
await a.screenshot({path:"stills/pdf.png",clip:{x:L.x+92,y:L.y+345,width:640,height:420}});
await a.goto(R+"?tool=whiteboard"); await a.waitForSelector("svg[aria-label='Collaborative whiteboard canvas']"); await col(); await a.getByRole("button",{name:"Reset view"}).first().click(); await a.mouse.move(1430,450); await a.waitForTimeout(1200);
await a.screenshot({path:"stills/ask.png",clip:{x:738,y:134,width:548,height:650}});
const ph=await login(b,u.ana,{viewport:{width:430,height:1400},deviceScaleFactor:3});
const [m,l]=await Promise.all([login(b,u.marco,{deviceScaleFactor:1}),login(b,u.lea,{deviceScaleFactor:1})]);
for(const p of [m,l]){await p.goto(R);await p.waitForSelector("[contenteditable=true]");}
await ph.goto(R); await ph.waitForSelector("[contenteditable=true]"); await ph.waitForTimeout(2000);
const endOf=async(p,t)=>{await p.locator(".ProseMirror li").filter({hasText:t}).first().click();await p.keyboard.press("End");};
await endOf(m,"Who gained most"); await endOf(l,"Korea printed"); await ph.waitForTimeout(1500);
const h=await ph.locator(".ProseMirror h2").first().boundingBox(); await ph.screenshot({path:"stills/notes.png",clip:{x:0,y:h.y-14,width:430,height:560}});
await b.close();
