import {mkdirSync,writeFileSync,rmSync} from "node:fs";
export class Rec{
  constructor(page,name,x=900,y=420){this.p=page;this.name=name;this.dir=`frames/${name}`;rmSync(this.dir,{recursive:true,force:true});mkdirSync(this.dir,{recursive:true});this.f=[];this.n=0;this.x=x;this.y=y;this.down=0;this.marks={};this.last=null;}
  async shot(hold=1){const img=`${String(this.n++).padStart(4,"0")}.jpg`;await this.p.screenshot({path:`${this.dir}/${img}`,type:"jpeg",quality:92,caret:"initial"});this.last=img;for(let i=0;i<hold;i++)this.push();}
  push(){this.f.push({i:this.last,x:+this.x.toFixed(1),y:+this.y.toFixed(1),d:this.down});}
  hold(k){for(let i=0;i<k;i++)this.push();}
  mark(k){this.marks[k]=this.f.length;}
  // real mouse ends at the target; the drawn cursor eases along a shallow arc
  async move(x,y,k=16){ if(!this.last)await this.shot(); const x0=this.x,y0=this.y,dx=x-x0,dy=y-y0,L=Math.hypot(dx,dy)||1;const cx=(x0+x)/2-dy/L*L*.1,cy=(y0+y)/2+dx/L*L*.1;
    for(let i=1;i<k;i++){const t=i/k,e=t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;this.x=(1-e)**2*x0+2*(1-e)*e*cx+e*e*x;this.y=(1-e)**2*y0+2*(1-e)*e*cy+e*e*y;this.push();}
    this.x=x;this.y=y;await this.p.mouse.move(x,y);await this.p.waitForTimeout(60);await this.shot();}
  async click(after=350,hold=2){this.down=1;this.push();this.push();this.down=0;await this.p.mouse.down();await this.p.mouse.up();await this.p.waitForTimeout(after);await this.shot(hold);}
  async to(loc,k=16){const b=await loc.boundingBox();if(!b)throw new Error("no box "+loc);await this.move(b.x+b.width/2,b.y+b.height/2,k);}
  async drag(x,y,k=20){this.down=1;await this.p.mouse.down();const x0=this.x,y0=this.y;for(let i=1;i<=k;i++){const t=i/k,e=t*t*(3-2*t);this.x=x0+(x-x0)*e;this.y=y0+(y-y0)*e;await this.p.mouse.move(this.x,this.y);await this.p.waitForTimeout(25);await this.shot();}await this.p.mouse.up();this.down=0;await this.p.waitForTimeout(150);await this.shot(3);}
  save(){writeFileSync(`frames/${this.name}.json`,JSON.stringify({frames:this.f,marks:this.marks}));console.log(this.name,this.f.length,"frames",this.n,"shots",this.marks);}
}
