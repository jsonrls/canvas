import {seedUsers,open,login,BASE} from "./lib.mjs"; import {Rec} from "./rec.mjs";
const u=await seedUsers(), b=await open(), R=BASE+"/rooms/history-study-group-14e34054a1?tool=assistant";
const a=await login(b,u.ana); await a.goto(R); await a.waitForTimeout(3500); await a.getByRole("button",{name:/collapse/i}).first().click(); await a.waitForTimeout(1200);
const names=()=>a.$$eval("button,[role=tab]",es=>es.filter(e=>e.offsetParent).map(e=>e.getAttribute("aria-label")||e.textContent.trim().slice(0,40)));
console.log(await names()); await a.screenshot({path:"x-pack0.png",scale:"css"});
const r=new Rec(a,"pack",820,560); await r.shot(14);
const gen=a.getByRole("button",{name:"Generate study pack"}).first(); await r.to(gen,18); await r.click(900,10); r.mark("dialog");
console.log(await names());
const go=a.getByRole("dialog").getByRole("button",{name:"Generate study pack"}); await r.to(go,16); await r.click(700,6); r.mark("wait");
const t0=Date.now(); for(let i=0;i<10;i++){await a.waitForTimeout(220);await r.shot(3);}
await a.waitForSelector("[aria-label='AI study pack views']",{timeout:150000}).catch(async e=>{await a.screenshot({path:"x-packfail.png",scale:"css"});throw e;}); console.log("generated in",Date.now()-t0); await a.waitForTimeout(1200);
console.log(await names()); r.mark("summary"); await r.shot(40);
const tab=n=>a.locator("[aria-label='AI study pack views']").getByRole("tab",{name:n}).or(a.locator("[aria-label='AI study pack views'] button").filter({hasText:n})).first();
await r.to(tab(/quiz/i),16); await r.click(900,14); r.mark("quiz");
const opt=a.locator("[aria-label='Answers for question 1'] button, [aria-label='Answers for question 1'] [role=radio], [aria-label='Answers for question 1'] label"); console.log("opts",await opt.count());
// pick the correct one if the UI marks it only after answering: choose option 2 then show feedback
await r.to(opt.nth(1),16); await r.click(900,30); r.mark("answered");
await r.to(tab(/cards/i),16); await r.click(900,14); r.mark("cards");
const card=a.getByRole("button",{name:/Reveal answer for flashcard 1/}); await r.to(card,16); await r.click(1000,30); r.mark("end"); r.save();
await a.screenshot({path:"x-pack.png",scale:"css"}); await b.close();
