import {seedUsers,open,login,BASE,admin} from "./lib.mjs"; import {Rec} from "./rec.mjs";
const u=await seedUsers(), b=await open(), SLUG="history-study-group-14e34054a1", R=`${BASE}/rooms/${SLUG}?tool=live`;
const {data:room}=await admin.from("rooms").select("id").eq("slug",SLUG).single();
for(const k of Object.keys(u)) await admin.from("room_members").upsert({room_id:room.id,user_id:u[k].id,role:k==="ana"?"owner":["marco","lea"].includes(k)?"editor":"viewer"});
const a=await login(b,u.ana); const others=Object.keys(u).filter(k=>k!=="ana");
const pages=Object.fromEntries(await Promise.all(others.map(async k=>[k,await login(b,u[k],{viewport:{width:400,height:300},deviceScaleFactor:1})])));
const api=(p,body)=>p.evaluate(async([s,body])=>{const r=await fetch(`/api/rooms/${s}/live`,{method:body?"POST":"GET",headers:{"Content-Type":"application/json"},body:body?JSON.stringify(body):undefined});return r.json();},[SLUG,body]);
let snap=await api(a); await api(a,{action:"present",questionId:null}); for(const q of snap.questions) await api(a,{action:"delete_question",questionId:q.id});
const Q=[{kind:"poll",prompt:"Which mattered most for the spread of printing?",options:["Cheaper books","Standard editions","Faster copying","More readers"],correctOption:null,timeLimitSeconds:null,settings:{}},
 {kind:"word_cloud",prompt:"One word for what printing changed",options:[],correctOption:null,timeLimitSeconds:null,settings:{}},
 {kind:"quiz",prompt:"Where was Gutenberg printing by about 1450?",options:["Venice","Mainz","Paris","Cologne"],correctOption:1,timeLimitSeconds:30,settings:{}},
 {kind:"scale",prompt:"How ready do you feel for Thursday?",options:[],correctOption:null,timeLimitSeconds:null,settings:{}}];
for(const draft of Q){const r=await api(a,{action:"create_question",draft}); if(r.error) console.log(r);} snap=await api(a); const ids=snap.questions.map(q=>q.id); console.log(snap.questions.map(q=>q.kind));
await a.goto(R); await a.waitForTimeout(2500); await a.getByRole("button",{name:/collapse/i}).first().click(); await a.waitForTimeout(1200);
const r=new Rec(a,"live",900,620); await r.shot(14);
await r.to(a.getByRole("button",{name:"Present question 1"}),18); await r.click(1200,8); r.mark("present");
console.log(await a.locator("[aria-label='Presenter controls'] button").evaluateAll(es=>es.map(e=>e.getAttribute("aria-label")||e.textContent)));
const openBtn=a.getByRole("button",{name:"Open voting",exact:true}).first(); await r.to(openBtn,14); await r.click(900,6);
for(let i=0;i<20;i++){const st=await api(a); if(st.session.isAccepting)break; if(i===6){console.log("opening by api");await api(a,{action:"set_accepting",value:true});} await a.waitForTimeout(300);} await r.shot(4); r.mark("open");
const votes=[0,0,1,0,2,0,1,3,0,2,0,1,0,3,2,0,1]; const watch=async(ms)=>{const t=Date.now();while(Date.now()-t<ms){await a.waitForTimeout(170);await r.shot(2);}};
for(let i=0;i<others.length;i++){ const x=await api(pages[others[i]],{action:"respond",questionId:ids[0],value:{option:votes[i]}}); if(x.error)console.log(i,x.error); if(i%3===2) await watch(800); }
await watch(3200); r.mark("votes");
const donut=a.getByRole("radio",{name:"Donut"}).or(a.getByText("Donut",{exact:true})).first(); await r.to(donut,16); await r.click(900,26); r.mark("donut");
await api(a,{action:"present",questionId:ids[1]}); await api(a,{action:"set_accepting",value:true}); await a.waitForTimeout(2600); await r.shot(8); r.mark("cloud");
const W=[["access"],["speed"],["access","cost"],["literacy"],["access"],["scale"],["speed","reach"],["cost"],["access"],["ideas"],["literacy","news"],["reach"],["speed"],["ideas"],["access","scale"],["cost"],["debate"]];
for(let i=0;i<others.length;i++){ const x=await api(pages[others[i]],{action:"respond",questionId:ids[1],value:{words:W[i]}}); if(x.error&&i<2)console.log(x); if(i%3===2) await watch(800); }
await watch(3600); r.mark("end"); r.save(); await a.screenshot({path:"x-live2.png",scale:"css"}); await b.close();
