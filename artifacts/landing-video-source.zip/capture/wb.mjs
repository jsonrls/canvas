import {seedUsers,open,login,BASE} from "./lib.mjs"; import {Rec} from "./rec.mjs";
const u=await seedUsers(), b=await open(), R=BASE+"/rooms/history-study-group-14e34054a1?tool=whiteboard";
const [a,m]=await Promise.all([login(b,u.ana),login(b,u.marco)]);
const S="svg[aria-label='Collaborative whiteboard canvas']";
for(const p of [a,m]){await p.goto(R);await p.waitForSelector(S);await p.waitForTimeout(1800);await p.addStyleTag({content:"svg[aria-label='Collaborative whiteboard canvas']{user-select:none;-webkit-user-select:none}"});await p.getByRole("button",{name:/collapse/i}).first().click();} await a.waitForTimeout(1500);
const T=(p,n)=>p.locator(".whiteboard-toolbar").getByRole("button",{name:n,exact:true}).first();
// clear what an earlier run left
{const c=a.getByRole("button",{name:"Clear all"}).last(); if(await c.isVisible().catch(()=>false)){await c.click();await a.locator(".whiteboard-confirm-danger").click();await a.waitForTimeout(1200);}}
console.log("left over", await a.locator(S).evaluate(e=>e.textContent.trim().length));
for(const p of [a,m]){await p.getByRole("button",{name:"Reset view"}).first().click();await p.waitForTimeout(400);}
const color=async(p,c)=>p.locator("input[type=color]").first().evaluate((el,c)=>{const s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value").set;s.call(el,c);el.dispatchEvent(new Event("input",{bubbles:true}));el.dispatchEvent(new Event("change",{bubbles:true}));},c);
const shape=async(p,t,x,y,x2,y2)=>{await T(p,t).click();await p.mouse.move(x,y);await p.mouse.down();await p.mouse.move(x2,y2,{steps:5});await p.mouse.up();await p.waitForTimeout(120);};
const text=async(p,x,y,s)=>{await T(p,"Text").click();await p.mouse.click(x,y);await p.waitForTimeout(150);const t=p.locator("textarea.whiteboard-text-editor");await t.focus();await t.pressSequentially(s,{delay:4});await t.press("Enter");await p.waitForTimeout(200);};
await color(a,"#2563eb"); await color(m,"#16866d");
for(const [s,y] of [["Metal type",220],["Oil-based ink",360],["Screw press",500]]){await shape(a,"Rectangle",120,y,366,y+84);await text(a,s==="Oil-based ink"?147:162,y+24,s);}
await shape(a,"Rectangle",496,352,730,452);await text(a,516,383,"Printed page");
for(const y of [262,402,542])await shape(a,"Arrow",376,y,486,402+(y-402)*.15);
await text(m,810,186,"Why did books get cheaper?");
await T(a,"Select").click(); await a.mouse.click(1380,620); await a.waitForTimeout(700);
await a.screenshot({path:"x-wb0.png",scale:"css"});
const r=new Rec(a,"whiteboard",640,640); await r.shot(14);
// Marco draws from his own browser
await T(m,"Draw").click(); await m.mouse.move(150,690); await m.mouse.down(); for(let i=1;i<=16;i++){await m.mouse.move(150+i*11.5,690+Math.sin(i/2.2)*5);} await m.mouse.up(); await text(m,160,704,"All three existed before 1450");
for(let i=0;i<4;i++){await a.waitForTimeout(150);await r.shot(3);} r.mark("marco");
await r.to(T(a,"Ellipse"),14); await r.click(150,2); await r.move(745,150,14); await r.drag(1265,262,18);
await r.to(T(a,"Arrow"),14); await r.click(150,2); await r.move(1005,270,14); await r.drag(1005,368,12);
await r.to(T(a,"Ellipse"),14); await r.click(150,2); await r.move(760,384,14); r.mark("blank"); await r.drag(1210,770,20); r.mark("ask");
const L=()=>a.locator(S).evaluate(e=>e.textContent.length); const before=await L(); const t0=Date.now(); let asked=false; let done=false;
while(Date.now()-t0<60000){ await a.waitForTimeout(250); if(r.f.length<r.marks.ask+34) await r.shot(2); if(await L()>before+8){done=true;break;} if(!asked&&Date.now()-t0>4000&&!(await a.locator(".study-tool__message").isVisible().catch(()=>false))){asked=true;console.log("manual ask");await T(a,"AI answer").click().catch(e=>console.log(e.message.slice(0,100)));} }
console.log("answered",done,Date.now()-t0, await a.locator(".study-tool__message").textContent().catch(()=>""));
await a.waitForTimeout(250); r.mark("answer"); await r.shot(8); await a.waitForTimeout(6000); await T(a,"Select").click();await a.mouse.click(1380,640); await a.waitForTimeout(400); r.x=1300;r.y=690; await r.shot(50); r.mark("end"); r.save();
await a.screenshot({path:"x-wb.png",scale:"css"}); await b.close();
